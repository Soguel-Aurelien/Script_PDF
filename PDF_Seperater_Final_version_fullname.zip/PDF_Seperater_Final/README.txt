Write the code below on terminal to run the script.

python main.py



***If you have not already installed libraries, first install with the code below;

This command loads the PyPDF2 library, which is necessary for reading and writing PDF files.

pip install PyPDF2


PyPDF2 is not enough to read the text on the page. We need to install this:

pip install pdfplumber
